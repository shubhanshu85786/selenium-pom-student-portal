# Student Portal – Automated UI Testing

**Project:** Student Portal – Automated UI Testing  
**Author:** Shubhanshu Bunkar | IIIT Bhopal  
**Tech Stack:** HTML, CSS, JavaScript, Python, Selenium WebDriver  
**Test Period:** Aug 2025 – Nov 2025  

---

## 📁 Project Structure

```
student_portal/
│
├── login.html               # Login page
├── dashboard.html           # Dashboard with results table
├── profile.html             # Profile update form
│
├── test_student_portal.py   # Selenium automated test suite
└── README.md
```

---

## 🚀 How to Run

### Step 1 – Install dependencies
```bash
pip install selenium webdriver-manager
```

### Step 2 – Run tests
```bash
python test_student_portal.py
```

Chrome browser will open automatically and run all 15 test cases.

---

## ✅ Test Cases Covered (15 Total)

| Module   | TC ID  | Description                          |
|----------|--------|--------------------------------------|
| Login    | TC-001 | Valid login redirects to dashboard   |
| Login    | TC-002 | Invalid password shows error         |
| Login    | TC-003 | Empty username shows error           |
| Login    | TC-004 | Empty password shows error           |
| Login    | TC-005 | Both fields empty shows error        |
| Login    | TC-006 | Password field is masked             |
| Login    | TC-007 | Enter key submits login form         |
| Dashboard| TC-008 | Welcome message shows username       |
| Dashboard| TC-009 | Results table shows 7 subjects       |
| Dashboard| TC-010 | Navigation links visible             |
| Dashboard| TC-011 | Logout redirects to login page       |
| Profile  | TC-012 | Valid profile saves successfully     |
| Profile  | TC-013 | Empty name shows error               |
| Profile  | TC-014 | Invalid email shows error            |
| Profile  | TC-015 | Invalid phone number shows error     |

---

## 🔐 Test Credentials

| Username  | Password  |
|-----------|-----------|
| student1  | pass123   |
| student2  | pass456   |
| admin     | admin123  |

---

## 📊 SQL – Data Validation Queries

Run these against your SQLite DB to validate UI data matches backend:

```sql
-- Check student record exists
SELECT * FROM students WHERE username = 'student1';

-- Verify subject count = 7
SELECT COUNT(*) FROM subjects WHERE student_id = 1;

-- Validate marks are within valid range
SELECT * FROM subjects WHERE marks < 0 OR marks > 100;
```
