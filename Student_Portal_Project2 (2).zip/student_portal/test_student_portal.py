"""
Student Portal – Selenium Automated Test Suite
Tool   : Selenium WebDriver + Python
Author : Shubhanshu Bunkar | IIIT Bhopal
Run    : python test_student_portal.py
"""

import time, os, unittest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager

# ─────────────────────────────────────────────────────────────
# ✅ IMPORTANT: Put your HTML files in the SAME folder as this
#    .py file. The BASE path below auto-detects that folder.
# ─────────────────────────────────────────────────────────────
BASE = os.path.dirname(os.path.abspath(__file__)).replace("\\", "/")
LOGIN_URL     = f"file:///{BASE}/login.html"
DASHBOARD_URL = f"file:///{BASE}/dashboard.html"
PROFILE_URL   = f"file:///{BASE}/profile.html"

VALID_USER = "student1"
VALID_PASS = "pass123"


def get_driver():
    options = Options()
    options.add_argument("--start-maximized")
    options.add_argument("--disable-web-security")
    options.add_argument("--allow-file-access-from-files")
    options.add_argument("--disable-features=IsolateOrigins,site-per-process")
    service = Service(ChromeDriverManager().install())
    return webdriver.Chrome(service=service, options=options)


def do_login(driver, username=VALID_USER, password=VALID_PASS):
    """Open login page, wait for it to load, then submit credentials."""
    driver.get(LOGIN_URL)
    # Wait until username field is actually present in DOM
    WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.ID, "username"))
    )
    driver.find_element(By.ID, "username").clear()
    driver.find_element(By.ID, "username").send_keys(username)
    driver.find_element(By.ID, "password").clear()
    driver.find_element(By.ID, "password").send_keys(password)
    driver.find_element(By.ID, "loginBtn").click()
    # Wait until dashboard loads
    WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.ID, "welcome-msg"))
    )


# ════════════════════════════════════════════════════════════
#  LOGIN TESTS  (TC-001 – TC-007)
# ════════════════════════════════════════════════════════════
class TestLogin(unittest.TestCase):

    def setUp(self):
        self.d = get_driver()

    def tearDown(self):
        self.d.quit()

    def _open_login(self):
        self.d.get(LOGIN_URL)
        WebDriverWait(self.d, 10).until(
            EC.presence_of_element_located((By.ID, "username"))
        )

    def test_TC001_valid_login_redirects_to_dashboard(self):
        """TC-001 Valid credentials redirect to dashboard"""
        do_login(self.d)
        self.assertIn("dashboard.html", self.d.current_url)
        print("✅ TC-001 PASSED")

    def test_TC002_invalid_password_shows_error(self):
        """TC-002 Wrong password shows error message"""
        self._open_login()
        self.d.find_element(By.ID, "username").send_keys(VALID_USER)
        self.d.find_element(By.ID, "password").send_keys("wrongpassword")
        self.d.find_element(By.ID, "loginBtn").click()
        WebDriverWait(self.d, 5).until(
            EC.visibility_of_element_located((By.ID, "error-msg"))
        )
        err = self.d.find_element(By.ID, "error-msg")
        self.assertTrue(err.is_displayed())
        self.assertIn("Invalid", err.text)
        print("✅ TC-002 PASSED")

    def test_TC003_empty_username_shows_error(self):
        """TC-003 Empty username shows validation error"""
        self._open_login()
        self.d.find_element(By.ID, "password").send_keys(VALID_PASS)
        self.d.find_element(By.ID, "loginBtn").click()
        WebDriverWait(self.d, 5).until(
            EC.visibility_of_element_located((By.ID, "error-msg"))
        )
        err = self.d.find_element(By.ID, "error-msg")
        self.assertIn("Username is required", err.text)
        print("✅ TC-003 PASSED")

    def test_TC004_empty_password_shows_error(self):
        """TC-004 Empty password shows validation error"""
        self._open_login()
        self.d.find_element(By.ID, "username").send_keys(VALID_USER)
        self.d.find_element(By.ID, "loginBtn").click()
        WebDriverWait(self.d, 5).until(
            EC.visibility_of_element_located((By.ID, "error-msg"))
        )
        err = self.d.find_element(By.ID, "error-msg")
        self.assertIn("Password is required", err.text)
        print("✅ TC-004 PASSED")

    def test_TC005_both_fields_empty_shows_error(self):
        """TC-005 Both fields empty shows error"""
        self._open_login()
        self.d.find_element(By.ID, "loginBtn").click()
        WebDriverWait(self.d, 5).until(
            EC.visibility_of_element_located((By.ID, "error-msg"))
        )
        err = self.d.find_element(By.ID, "error-msg")
        self.assertTrue(err.is_displayed())
        print("✅ TC-005 PASSED")

    def test_TC006_password_field_is_masked(self):
        """TC-006 Password input type should be password"""
        self._open_login()
        pwd = self.d.find_element(By.ID, "password")
        self.assertEqual(pwd.get_attribute("type"), "password")
        print("✅ TC-006 PASSED")

    def test_TC007_enter_key_submits_form(self):
        """TC-007 Enter key on password field submits login"""
        self._open_login()
        self.d.find_element(By.ID, "username").send_keys(VALID_USER)
        self.d.find_element(By.ID, "password").send_keys(VALID_PASS + Keys.RETURN)
        WebDriverWait(self.d, 10).until(
            EC.presence_of_element_located((By.ID, "welcome-msg"))
        )
        self.assertIn("dashboard.html", self.d.current_url)
        print("✅ TC-007 PASSED")


# ════════════════════════════════════════════════════════════
#  DASHBOARD TESTS  (TC-008 – TC-011)
# ════════════════════════════════════════════════════════════
class TestDashboard(unittest.TestCase):

    def setUp(self):
        self.d = get_driver()
        do_login(self.d)

    def tearDown(self):
        self.d.quit()

    def test_TC008_welcome_message_contains_username(self):
        """TC-008 Welcome message shows logged-in username"""
        msg = self.d.find_element(By.ID, "welcome-msg").text
        self.assertIn(VALID_USER, msg)
        print("✅ TC-008 PASSED")

    def test_TC009_results_table_shows_7_subjects(self):
        """TC-009 Results table has exactly 7 rows"""
        rows = self.d.find_elements(By.CSS_SELECTOR, "#results-table tbody tr")
        self.assertEqual(len(rows), 7)
        print("✅ TC-009 PASSED")

    def test_TC010_nav_links_visible(self):
        """TC-010 Dashboard and Profile nav links are present"""
        links = [a.text for a in self.d.find_elements(By.CSS_SELECTOR, "nav a")]
        self.assertIn("Dashboard", links)
        self.assertIn("Profile", links)
        print("✅ TC-010 PASSED")

    def test_TC011_logout_redirects_to_login(self):
        """TC-011 Clicking Logout redirects to login page"""
        self.d.find_element(By.ID, "logout-btn").click()
        WebDriverWait(self.d, 10).until(
            EC.presence_of_element_located((By.ID, "loginBtn"))
        )
        self.assertIn("login.html", self.d.current_url)
        print("✅ TC-011 PASSED")


# ════════════════════════════════════════════════════════════
#  PROFILE TESTS  (TC-012 – TC-015)
# ════════════════════════════════════════════════════════════
class TestProfile(unittest.TestCase):

    def setUp(self):
        self.d = get_driver()
        do_login(self.d)
        self.d.get(PROFILE_URL)
        WebDriverWait(self.d, 10).until(
            EC.presence_of_element_located((By.ID, "saveBtn"))
        )

    def tearDown(self):
        self.d.quit()

    def _fill_profile(self, name="Shubhanshu Bunkar", roll="2023BIT045",
                      year="2", branch="IT",
                      email="shubhanshu@iiitbhopal.ac.in", phone="7000882812"):
        d = self.d
        d.find_element(By.ID, "fullname").clear()
        if name:
            d.find_element(By.ID, "fullname").send_keys(name)
        d.find_element(By.ID, "rollno").clear()
        if roll:
            d.find_element(By.ID, "rollno").send_keys(roll)
        if year:
            Select(d.find_element(By.ID, "year")).select_by_value(year)
        if branch:
            Select(d.find_element(By.ID, "branch")).select_by_value(branch)
        d.find_element(By.ID, "email").clear()
        if email:
            d.find_element(By.ID, "email").send_keys(email)
        d.find_element(By.ID, "phone").clear()
        if phone:
            d.find_element(By.ID, "phone").send_keys(phone)

    def test_TC012_valid_profile_saves_successfully(self):
        """TC-012 All valid inputs shows success message"""
        self._fill_profile()
        self.d.find_element(By.ID, "saveBtn").click()
        WebDriverWait(self.d, 5).until(
            EC.visibility_of_element_located((By.ID, "success-msg"))
        )
        self.assertTrue(self.d.find_element(By.ID, "success-msg").is_displayed())
        print("✅ TC-012 PASSED")

    def test_TC013_empty_name_shows_error(self):
        """TC-013 Blank Full Name shows err-name"""
        self._fill_profile(name="")
        self.d.find_element(By.ID, "saveBtn").click()
        WebDriverWait(self.d, 5).until(
            EC.visibility_of_element_located((By.ID, "err-name"))
        )
        self.assertTrue(self.d.find_element(By.ID, "err-name").is_displayed())
        print("✅ TC-013 PASSED")

    def test_TC014_invalid_email_shows_error(self):
        """TC-014 Email without @ shows err-email"""
        self._fill_profile(email="invalidemail")
        self.d.find_element(By.ID, "saveBtn").click()
        WebDriverWait(self.d, 5).until(
            EC.visibility_of_element_located((By.ID, "err-email"))
        )
        self.assertTrue(self.d.find_element(By.ID, "err-email").is_displayed())
        print("✅ TC-014 PASSED")

    def test_TC015_short_phone_shows_error(self):
        """TC-015 Phone less than 10 digits shows err-phone"""
        self._fill_profile(phone="12345")
        self.d.find_element(By.ID, "saveBtn").click()
        WebDriverWait(self.d, 5).until(
            EC.visibility_of_element_located((By.ID, "err-phone"))
        )
        self.assertTrue(self.d.find_element(By.ID, "err-phone").is_displayed())
        print("✅ TC-015 PASSED")


# ════════════════════════════════════════════════════════════
if __name__ == "__main__":
    print("\n" + "="*55)
    print("  Student Portal – Selenium Test Suite")
    print("  Author : Shubhanshu Bunkar | IIIT Bhopal")
    print("="*55 + "\n")
    unittest.main(verbosity=2)
